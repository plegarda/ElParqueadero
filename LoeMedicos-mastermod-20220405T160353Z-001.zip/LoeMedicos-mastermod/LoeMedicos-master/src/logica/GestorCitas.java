package logica;

import datos.Ingreso;
import datos.Salida;
import datos.Conductor;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import utilidades.GestorPersistencia;

/**
 *
 * @author TP303
 */
public class GestorCitas {
    private Map<String, Ingreso> listaCitas;
    public GestorCitas(){
        if (listaCitas == null){
            listaCitas = (Map<String, Ingreso> )GestorPersistencia.recuperar();
            if (listaCitas == null){
                listaCitas = new HashMap<>();
            }
        }
    }
//    public Cita crearCita(Conductor elpac, Date fecha, Salida opcion){
//        return null;
//    }
//    public Cita crearCita(Conductor elPaciente,Date fecha, Salida opcion){
//        return null;
//    }
    public Ingreso crearCita(String nombre, String identificacion, Date fechaNac, 
            Date fecha, Salida opcion){
        if (nombre == null || identificacion == null || fechaNac == null || fecha == null || opcion == null
                || nombre.isEmpty() || identificacion.isEmpty()){
            return null;
        }else{
            Conductor elConductor = this.crearConductor(identificacion, fechaNac);
            Ingreso c = new Ingreso(elConductor, fecha);
            //c.modificaElPaciente(elPaciente);
            //c.modificaFecha(fecha);
            //c.modificaOpcion(opcion);
            listaCitas.put(c.getCodigo(), c);
            GestorPersistencia.guardar(listaCitas);
            return c;
        }
        
        
    }
    private Conductor crearConductor(String nombre, String identificacion, Date fechaNac){
        Conductor p = new Conductor();
        p.modificaIdentificacion(identificacion);
        p.modificaPlaca(nombre);
        return p;
    }
    public Map<String, Ingreso> obtenerLista(){
        return this.listaCitas;
    }

    private Conductor crearConductor(String identificacion, Date fechaNac) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public Ingreso crearIngreso(String nombre, String identificacion, Date fechaNac, Date fecha, Salida laopcion) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
