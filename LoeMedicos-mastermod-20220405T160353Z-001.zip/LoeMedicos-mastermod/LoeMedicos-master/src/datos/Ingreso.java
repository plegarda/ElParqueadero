/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package datos;

import java.io.Serializable;
import java.util.Date;
import java.util.Timer;

/**
 *
 * @author 
 */
public class Ingreso implements Serializable{
    private String identificacion;
    private Timer hora;
    private Date fecha;
    private String placa;
    private Conductor elConductor;
    private String codigo;
    
    public Ingreso(Conductor elConductor, Date fecha, Timer hora){
        this.elConductor = elConductor;
        this.fecha = fecha;
        this.codigo = elConductor.obtenerIdentificacion()+fecha.getTime();
        
    }

    public Ingreso(Conductor elConductor, Date fecha) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    public Conductor obtenerConductor(){
        return this.elConductor;
    }
    public Timer obtenerHora(){
        return this.hora;
    }
    public Date obtenerFecha(){
        return this.fecha;
    }

    public String getCodigo() {
        return codigo;
    }
    
    @Override
    public String toString() {
        return " El ingreso "+this.codigo+"\n es para conductor identificado con "+elConductor.obtenerIdentificacion()+ "\n el dia "+this.fecha + "\n a las "+this.hora;
    }
    
}
