package datos;

import java.io.Serializable;

/**
 *
 * @author TP303
 */
public enum Salida implements Serializable{
    MEDICINA_GENERAL,ODONTOLOGIA ;
}
